const fs=require('fs'),assert=require('assert');
const html=fs.readFileSync('index.html','utf8');
const extract=id=>html.match(new RegExp('<script id="'+id+'">([\\s\\S]*?)<\\/script>'))[1];
const C=new Function(extract('rush-engine')+extract('campaign-engine')+';return Campaign;')();
function test(name,fn){fn();console.log('PASS '+name);}
function play(s){let n=0;while(!s.ended&&n++<5000){if(s.dialog)C.choose(s,s.repair?0:C.goal(s).correct);else if(s.act==='explore'&&s.mission===2&&C.near(s)){for(let i=0;i<3;i++)C.checkItem(s,i);}else if(!C.interact(s)&&!s.path.length){const g=C.goal(s);C.go(s,g.x,g.y);}C.tick(s,.1);}assert(n<5000);}
test('warehouse showroom and every mission connected',()=>{const s=C.create(1);for(const g of [...C.missions,...C.tools]){assert(C.walkable(g.x,g.y),g.name);assert(C.route(s.player,g).length,g.name);}assert(C.route(s.player,{x:.3,y:-5.5}).length);});
test('timer waits for movement and never skips missions',()=>{const s=C.create();C.tick(s,60);assert.equal(s.time,0);C.go(s,2,5.8);C.tick(s,100);assert.equal(s.mission,0);});
test('complete order visits eight roles and exits within 180 seconds',()=>{const s=C.create(11);play(s);assert(s.won);assert(s.time<180);assert.equal(new Set(s.results.map(r=>r.role)).size,8);assert.equal(s.mission,9);assert(s.invoice&&s.escaped);console.log('Route completion:',s.time.toFixed(1),'seconds');});
test('dialog freezes time and cannot nest',()=>{const s=C.create();s.mission=1;s.player={x:8.2,y:-1.7};assert(C.interact(s));C.tick(s,10,{x:1});assert.equal(s.time,0);assert(!C.go(s,1,1));assert(!C.interact(s));assert(C.choose(s,0));assert.equal(s.mission,2);});
test('wrong choice permits explicit recovery',()=>{const s=C.create();s.mission=1;s.player={x:8.2,y:-1.7};C.interact(s);C.choose(s,1);assert(s.repair&&s.dialog);const before=s.rating;C.choose(s,0);assert.equal(s.time,3);assert(s.rating>before);assert(!s.dialog);});
test('receipt requires three unique nearby checks',()=>{const s=C.create();s.mission=2;assert(!C.checkItem(s,0));s.player={x:8.9,y:-5.3};assert(C.checkItem(s,0));assert(!C.checkItem(s,0));C.checkItem(s,1);assert.equal(s.mission,2);C.checkItem(s,2);assert.equal(s.mission,3);});
test('transformation preserves position and checkout is mandatory',()=>{const s=C.create();s.mission=8;s.player={x:1.85,y:2.7};C.interact(s);assert.equal(s.act,'halloween');assert.equal(s.player.x,1.85);s.player={x:2,y:6.3};assert(!C.interact(s));s.collected=[0,1,2];assert(!C.interact(s));s.player={x:1.85,y:2.7};assert(C.interact(s));s.player={x:2,y:6.3};assert(C.interact(s));assert(s.won);});
test('zero budget and deadline end safely',()=>{const s=C.create();s.started=true;s.act='halloween';s.budget=0;const x=s.player.x;C.tick(s,1,{x:1});assert.equal(s.player.x,x);assert(s.ended&&!s.won);const t=C.create();t.started=true;C.tick(t,180);assert(t.ended&&!t.won);});
test('pause collision and dash guards',()=>{const s=C.create();s.paused=true;C.tick(s,8);assert(!C.go(s,2,3));assert(!C.dash(s));s.paused=false;C.go(s,2,3);assert(C.dash(s));assert(!C.dash(s));C.tick(s,20,{x:-1,y:0});assert(C.walkable(s.player.x,s.player.y));});
new Function(extract('sim-ui'));console.log('UI syntax valid; real device rendering remains separate.');

test('home exposes only one game entry',()=>{const home=html.match(/<section class="modal" id="home">([\s\S]*?)<\/section>/)[1];assert.equal((home.match(/<button/g)||[]).length,1);assert(!html.includes('id="classicMode"'));assert(!html.includes('id="bonusBtn"'));});
