// Current campaign is the free-exploration version.
require('./exploration.test.cjs');
