console.log('Legacy timed-campaign calibration archived. Exploration win rate requires new human playtesting; run node qa/exploration.test.cjs for route regression checks.');
