const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync('index.html','utf8').match(/<script id="rush-engine">([\s\S]*?)<\/script>/)[1];
const R=vm.runInNewContext(source+';Rush');
let wins=0,bestWins=0;function run(seed,policy){const s=R.create(seed);let n=seed+911;for(const when of [...Array.from({length:16},(_,i)=>8+Math.floor(i/2)*19+(i%2?10:2)),160]){R.tick(s,when-s.time);n=(1664525*n+1013904223)>>>0;const q=n/4294967296;R.choose(s,when===160?0:policy==='best'?0:q<.5?0:q<.85?1:2);R.tick(s,.8);}R.tick(s,180-s.time);return s;}
for(let i=1;i<=10000;i++){wins+=run(i,'mixed').won;bestWins+=run(i,'best').won;}
console.log('Mixed policy (50/35/15%, best recovery):',wins/100,'% win. Best choices:',bestWins/100,'%');
const s=run(123,'best');assert.equal(s.time,180);assert.equal(s.results.length,17);assert.equal(new Set(s.results.filter(x=>x.key!=='rescue').map(x=>x.role)).size,8);console.log('PASS all eight roles, 16 decisions and recovery in exactly 180 active seconds');
const p=R.create(1);p.paused=true;R.tick(p,40);assert.equal(p.time,0);assert.equal(R.choose(p,0),false);console.log('PASS pause freezes time and decisions');
const t=R.create(2);R.tick(t,17.8);assert(R.choose(t,0));R.tick(t,.3);assert(!t.done['0:0']);R.tick(t,.5);assert(t.done['0:0']);assert(!t.results.find(x=>x.key==='0:0').timeout);console.log('PASS last-moment choice resolves without false timeout');
const idle=R.create(8);R.tick(idle,180);assert.equal(idle.results.length,17);assert(!idle.won);R.tick(idle,100);assert.equal(idle.results.length,17);console.log('PASS unattended run ends and settles exactly once');
assert(wins/10000>.28&&wins/10000<.38,'Calibrate mixed policy to approximately one third');
