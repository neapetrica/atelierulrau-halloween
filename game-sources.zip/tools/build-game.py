from pathlib import Path
root=Path(__file__).resolve().parent.parent
source=root/'src/client-game.html'
(root/'index.html').write_text(source.read_text(encoding='utf-8'),encoding='utf-8')
print('Built client Halloween game: index.html')
