from pathlib import Path
import json
root=Path(__file__).resolve().parent.parent
import os
os.chdir(root)
u=Path('src/sim-ui.js');s=u.read_text(encoding='utf-8').replace("'TOI · '","'TU · '").replace("ctx.fillText('ICI'","ctx.fillText('AICI'").replace("'Une pause bien méritée.'.replace('Une pause bien méritée.','O pauză bine meritată.')","'O pauză bine meritată.'").replace("'Choisis un passage libre.'.replace('Choisis un passage libre.','Alege un culoar liber.')","'Alege un culoar liber.'");u.write_text(s,encoding='utf-8')
old=Path('src/halloween-before-simulator.html').read_text(encoding='utf-8');assert 'Client cu ofertă' in old
shell=Path('src/sim-shell.html').read_text(encoding='utf-8')
shell=shell.replace('</style>',Path('src/rush-style.css').read_text(encoding='utf-8-sig')+'\n</style>')
shell=shell.replace('<!--ENGINE-->',Path('src/rush-markup.html').read_text(encoding='utf-8-sig')+'\n<script id="rush-engine">'+Path('src/rush-engine.js').read_text(encoding='utf-8-sig')+'</script>\n<!--ENGINE-->')
s=s.replace("last=now;if(!document.hidden)","last=now;if(state==='rush'){rushFrame(now);requestAnimationFrame(loop);return;}if(!document.hidden)")
s=s.rsplit('})();',1)[0]+Path('src/rush-ui.js').read_text(encoding='utf-8-sig')+'\n})();'
shell=shell.replace('</style>',Path('src/campaign-style.css').read_text(encoding='utf-8-sig')+'\n</style>')
shell=shell.replace('<!--ENGINE-->',Path('src/campaign-markup.html').read_text(encoding='utf-8-sig')+'\n<script id="campaign-engine">'+Path('src/campaign-engine.js').read_text(encoding='utf-8-sig')+'</script>\n<!--ENGINE-->')
s=s.replace("last=now;if(state==='rush')", "last=now;if(state==='campaign'){cpFrame(now);requestAnimationFrame(loop);return;}if(state==='rush')")
s=s.rsplit('})();',1)[0]+Path('src/campaign-ui.js').read_text(encoding='utf-8-sig')+'\n})();'
shell=shell.replace('<!--ENGINE-->','<script id="sim-engine">\n'+Path('src/sim-engine.js').read_text(encoding='utf-8')+'\n</script>')
shell=shell.replace('<!--UI-->','<script id="sim-ui">\n'+s+'\n</script>')
shell=shell.replace('<!--BONUS-->','<script type="application/json" id="bonus-source">'+json.dumps(old,ensure_ascii=False).replace('<','\\u003c')+'</script>')
Path('index.html').write_text(shell,encoding='utf-8')
p=Path('qa/game.test.cjs');s=p.read_text(encoding='utf-8');s=s.replace("const html=fs.readFileSync(require('path').join(__dirname,'../index.html'),'utf8');","const file=fs.readFileSync(require('path').join(__dirname,'../index.html'),'utf8');\nconst html=file.includes('id=\"bonus-source\"')?JSON.parse(file.match(/<script type=\"application\\/json\" id=\"bonus-source\">([\\s\\S]*?)<\\/script>/)[1]):file;");p.write_text(s,encoding='utf-8')
